"use strict";

for (var i = 0; i <= 100; i += 2)
{
	if (i === 50)
	{
		//break;
		continue;
	}

	console.log("This is position for I: " + i);
}






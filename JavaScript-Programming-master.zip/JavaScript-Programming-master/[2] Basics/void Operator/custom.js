"use strict";

void function VoidFunc()
{
	console.log("Hi");
} ();

VoidFunc();







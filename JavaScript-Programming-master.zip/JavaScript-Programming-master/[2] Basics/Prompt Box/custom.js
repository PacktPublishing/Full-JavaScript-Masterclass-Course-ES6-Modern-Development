"use strict";

// Hello this is an epic variable
//var i = 9;

/*
var i1 = 1;
var i2 = 1;
var i3 = 1;
var i4 = 1;
*/

var awesome = prompt("Please enter your name", "Batman")

console.log(awesome);
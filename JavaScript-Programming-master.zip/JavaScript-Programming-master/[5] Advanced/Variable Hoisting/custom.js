"use strict";


num = 10;
console.log(num);
var num;

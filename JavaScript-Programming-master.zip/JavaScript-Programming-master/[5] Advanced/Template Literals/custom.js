"use strict";


var str = `Hello
fsd
f
sdf
s
dfWorld`;

var age = 26;

var str2 = `My age is ${age * 7} and I am Batman`;

console.log(str);
console.log(str2);
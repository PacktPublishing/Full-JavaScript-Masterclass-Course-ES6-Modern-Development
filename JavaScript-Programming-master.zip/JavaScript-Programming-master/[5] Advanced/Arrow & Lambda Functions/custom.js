"use strict";



var epicVar = () =>
{
	console.log("Hello World");
}

epicVar();



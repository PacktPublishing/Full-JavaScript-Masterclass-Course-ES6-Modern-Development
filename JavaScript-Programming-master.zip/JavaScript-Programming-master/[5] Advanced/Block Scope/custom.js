"use strict";

function EpicFunc()
{
	var epicNum = 789;

	console.log(epicNum);

	{
		let epicNum = 800;
		console.log(epicNum);
	}

	console.log(epicNum);
}

EpicFunc();











"use strict";

var dateObj = new Date();

console.log(dateObj);
console.log(dateObj.getFullYear());
console.log(dateObj.toString());
console.log(dateObj.toTimeString());
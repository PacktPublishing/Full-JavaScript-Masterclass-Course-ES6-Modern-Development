"use strict";

var var1 = false;
var boolObj = new Boolean(false);

console.log(var1);
console.log(boolObj.valueOf());
"use strict";

var var1 = "Hello World";
var stringObj = new String("Hello World");

console.log(var1);
console.log(stringObj);
console.log(stringObj.length);
console.log(stringObj.toUpperCase());
console.log(stringObj.valueOf());